<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Caleb Resume</title>
        <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Saira+Extra+Condensed:500,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,800,800i" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
            <a class="navbar-brand js-scroll-trigger" href="#page-top">
                <span class="d-block d-lg-none">Caleb Muasya</span>
                <span class="d-none d-lg-block"><img class="img-fluid img-profile rounded-circle mx-auto mb-2" src="assets/img/cm.jpg" alt="..." /></span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#about">About</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#experience">Experience</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#education">Education</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#skills">Skills</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#interests">Interests</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#Volunteer Work">Volunteer work</a></li>
                    <li class="nav-item"><a class="nav-link js-scroll-trigger" href="#awards">Awards</a></li>
                </ul>
            </div>
        </nav>
        <!-- Page Content-->
        <div class="container-fluid p-0">
            <!-- About-->
            <section class="resume-section" id="about">
                <div class="resume-section-content">
                    <h1 class="mb-0">
                        Caleb
                        <span class="text-primary">Muasya</span>
                    </h1>
                    <div class="subheading mb-5">
                        P O BOX 34293 - 00100 GPO NAIROBI · KENYA · +254 (0) 721 426 058 ·
                        <a href="mailto:name@email.com"> mmcaleb@gmail.com</a>
                    </div>
                    <p class="lead mb-5">I am experienced in leveraging agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition.</p>
                    <div class="social-icons">
                        <a class="social-icon" href="https://www.linkedin.com/in/caleb-muasya/"><i class="fab fa-linkedin-in"></i></a>
                        <a class="social-icon" href="https://twitter.com/TuzaCx"><i class="fab fa-twitter"></i></a>
                        <a class="social-icon" href="https://facebook.com/mmcaleb/"><i class="fab fa-facebook-f"></i></a>
                    </div>
                </div>
            </section>
            <hr class="m-0" />
            <!-- Experience-->
            <section class="resume-section" id="experience">
                <div class="resume-section-content">
                    <h2 class="mb-5">Experience</h2>
                    <div class="d-flex flex-column flex-md-row justify-content-between mb-5">
                        <div class="flex-grow-1">
                            <h3 class="mb-0">Business Development Manager</h3>
                            <div class="subheading mb-3">SGA Kenya Limited</div>
                            <p> •	Manage departmental budgets by allocating resources in line with the set business strategies.</p>
                            <p>    •	Leading a multi-level and interdisciplinary teams in operational processes involving compliance to statutory requirements, business continuity plans, business ethics in line with international standards, industry and client expectations.</p>
                            <p> •	Adherence to procurement standards in supply chain management and service level agreements with vendors.</p>
                            <p> •	Spearheading market research to understand market needs and competitor solutions.</p>
                            <p> •	Development of products and services that exceed client expectations and fill gaps in the market.</p>
                            <p> •	Managing business relationships to increase our wallet share among existing clients in different sectors including financial institutions, manufacturers, FMCG distributors and hospitality players.</p>
                            <p> •	Growing the business by on boarding new clients in taking up security solutions.
                            </p>
                        </div>
                        <div class="flex-shrink-0"><span class="text-primary">January 2018 - Present</span></div>
                    </div>
                    <div class="d-flex flex-column flex-md-row justify-content-between mb-5">
                        <div class="flex-grow-1">
                            <h3 class="mb-0">Merchant Relationship Manager</h3>
                            <div class="subheading mb-3">KCB Bank Kenya Limited</div>
                            <p>•	Relationship Management: Managing the bank’s corporate and retail clients by offering world class payment solutions</p>
                            <p>  •	Liability Growth and Income Generation: Driving growth of bank revenues by promoting cashless payment solutions to businesses through the provision of card payment machines, online payment gateways, mobile money to achieve our financial targets.</p>
                            <p>  •	Operations and Audits: Assisting in account reconciliations, roll out and resolution of challenges related to user experiences in payment solutions.</p>
                            <p> •	Conducting market research in order to align bank products to client needs</p>
                            <p>  •	Leveraging on my excellent account management skills to collect competitor products’ insights in order to develop cutting edge solutions to ‘lock’ my business clients</p>
                            <p> •	Drive market campaigns to appreciate and award clients</p>
                            <p> •	Cost containment: Ensuring that operations adhere to financial prudence guidelines</p>
                            <p> • Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps. Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom line.</p>
                        </div>
                        <div class="flex-shrink-0"><span class="text-primary">July 2008 - October 2012, May 2016 - December 2017</span></div>
                    </div>
                    <div class="d-flex flex-column flex-md-row justify-content-between mb-5">
                        <div class="flex-grow-1">
                            <h3 class="mb-0">Assistant Client Experience Manager</h3>
                            <div class="subheading mb-3">KCB Bank Kenya Limited</div>
                            <p>•	Managing retail and corporate clients by offering financial solutions.</p>
                            <p>    •	Keeping excellent client and bank records for business growth and operational procedures</p>
                            <p>  •	Keeping good procurement inventories and management of human resources</p>
                            <p> •	Evaluating all service delivery touch points, processes and implementation of strategies to address any service gaps</p>
                            <p> •	Manage, coach and provide leadership in the branch
                            </p>
                        </div>
                        <div class="flex-shrink-0"><span class="text-primary">August 2012 - May 2016</span></div>
                    </div>
                    <div class="d-flex flex-column flex-md-row justify-content-between">
                        <div class="flex-grow-1">
                            <h3 class="mb-0">Assistant Administrator</h3>
                            <div class="subheading mb-3">ABSA Bank Kenya Limited</div>
                            <p>•	Logging and resolving client queries from the Bank’s branch network and retail clients </p>
                            <p>    •	Ensuring proper storage of Bank and clients’ records
                            </p>
                        </div>
                        <div class="flex-shrink-0"><span class="text-primary">February 2008 - June 2008</span></div>
                    </div>
                </div>
            </section>
            <hr class="m-0" />
            <!-- Education-->
            <section class="resume-section" id="education">
                <div class="resume-section-content">
                    <h2 class="mb-5">Education</h2>
                    <div class="d-flex flex-column flex-md-row justify-content-between mb-5">
                        <div class="flex-grow-1">
                            <h3 class="mb-0">University of Nairobi</h3>
                            <div class="subheading mb-3">Master of Arts Degree</div>
                            <div>Project Planning and Management</div>
                                                    </div>
                        <div class="flex-shrink-0"><span class="text-primary">October 2010 - September 2015</span></div>
                    </div>

                    <div class="d-flex flex-column flex-md-row justify-content-between mb-5">
                        <div class="flex-grow-1">
                            <h3 class="mb-0">University of Nairobi</h3>
                            <div class="subheading mb-3">Bachelor of Arts Degree</div>
                            <div>Anthropology</div>
                        </div>
                        <div class="flex-shrink-0"><span class="text-primary">October 2002 - December 2006</span></div>
                    </div>

                    <div class="d-flex flex-column flex-md-row justify-content-between">
                        <div class="flex-grow-1">
                            <h3 class="mb-0">Lenana School</h3>
                            <div class="subheading mb-3">KCSE</div>

                        </div>
                        <div class="flex-shrink-0"><span class="text-primary">August 2002 - May 2006</span></div>
                    </div>
                </div>
            </section>
            <hr class="m-0" />
            <!-- Skills-->
            <section class="resume-section" id="skills">
                <div class="resume-section-content">
                    <h2 class="mb-5">Skills</h2>

                    <div class="subheading mb-3">Competences</div>
                    <ul class="fa-ul mb-0">
                        <li>
                            <span class="fa-li"><i class="fas fa-check"></i></span>
                            Strategic Management
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-check"></i></span>
                            Relationship Management
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-check"></i></span>
                            Market Intelligence
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-check"></i></span>
                            Program Coordination and Implementation
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-check"></i></span>
                            Project Management
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-check"></i></span>
                            Product development
                        </li>

                        <li>
                            <span class="fa-li"><i class="fas fa-check"></i></span>
                            Business Growth and Development
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-check"></i></span>
                            Administration
                        </li>
                    </ul>
                </div>
            </section>
            <hr class="m-0" />
            <!-- Leadership-->
            <section class="resume-section" id="Volunteer Work">
                <div class="resume-section-content">
                    <h2 class="mb-5">Volunteer Work</h2>
                    <p> Currently serving as a SDG Champion in SGA</p>
                    <p> Served as a Digital Financial Services Champion in KCB Westgate</p>
                    <p> Served as the Corporate Social Responsibility and Service Focus Team Leader in KCB UN Gigiri </p>
                    <p> Served as a Board Member, Communication Lead and Youth Leader in my local Church </p>
                </div>
            </section>
            <hr class="m-0" />
            <!-- Awards-->
            <section class="resume-section" id="awards">
                <div class="resume-section-content">
                    <h2 class="mb-5">Awards</h2>
                    <ul class="fa-ul mb-0">
                        <li>
                            <span class="fa-li"><i class="fas fa-trophy text-warning"></i></span>
                            The Best Merchant Relationship Manager in KCB Bank in the year 2017
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-trophy text-warning"></i></span>
                            Led KCB Westgate Branch to the Best Performing Branch Award in the year 2016
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-trophy text-warning"></i></span>
                            Led KCB UN Gigiri Branch to Top Position in Client Service and Business Growth in the year 2015
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-trophy text-warning"></i></span>
                            Led SGA Cash Management to be the most profitable division in the years 2019 and 2020
                        </li>
                        <li>
                            <span class="fa-li"><i class="fas fa-trophy text-warning"></i></span>
                            Rolled out new product lines in cash management that has increased SGA's wallet share in the market
                        </li>

                    </ul>
                </div>
            </section>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
